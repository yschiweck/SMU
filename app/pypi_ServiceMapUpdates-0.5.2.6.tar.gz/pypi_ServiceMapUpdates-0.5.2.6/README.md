# Introduction 
This is a python package called by azure build pipelines. It reads the current service parameters from the environemnt and updates the service map. 
