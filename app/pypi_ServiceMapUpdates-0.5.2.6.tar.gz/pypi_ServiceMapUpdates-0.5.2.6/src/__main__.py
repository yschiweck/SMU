from src.update_automation import *
from os.path import exists


def main():
    logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
    read_metadata()
    if exists(properties_file):
        get_metadata_from_yml(properties_file)
        logging.info(service_metadata)
        name_of_service: str = service_metadata[service_name]
        version_to_be_tested: str = service_metadata[metadata][service_version]
        try:
            update_version(service_id_of(name_of_service), version_to_be_tested)
        except KeyError as err:
            logging.info("an error occurred.")
            logging.critical(err)
        os.remove(properties_file)
        return
    else:
        logging.info("properties file not found.")
        return


if __name__ == "__main__":
    main()
