import logging
import json
from os.path import exists
import requests as requests
import os
import yaml
from typing import Tuple


class Operation:
    HOST = "https://servicemap.av360.org"
    ENTITY_PACK = HOST + "/api/entityPackEntity"
    EXEC_ENTITY = HOST + "/api/operation/executeEntity"
    EXEC_QRY = HOST + "/api/query/executeQuery"
    LOGIN = HOST + "/api/auth/login"


auth: dict = {
    "userName": "AzurePipeline",
    "password": "=PU`#PMV5ym8,N:V",
    "rememberMe": False
}
auth_headers: dict = {
    'Content-Type': 'application/json'
}

auth_token: str = json.loads(
    requests.post(url=Operation.LOGIN, headers=auth_headers, json=auth).content.decode("utf-8"))["token"]
headers: dict = {
    "Accept": "application/json",
    "Accept-Language": "de,en-US;q=0.7,en;q=0.3",
    "Accept-Encoding": "gzip,deflate,br",
    "Content-Type": "application/json",
    "Authorization": "Bearer " + auth_token,
    "Origin": "https://servicemap.av360.org",
    "Content-Length": "628",
    "Connection": "keep-alive"
}

metadata_yml_file: str = "metadata.yml"
metadata_yaml_file: str = "metadata.yaml"
properties_file: str = "properties.yml"
service_name: str = "name"
service_version: str = "version"
metadata: str = "metadata"
service_metadata: dict = \
    {
        service_name: "",
        metadata:
            {
                service_version: ""
            }
    }


def read_metadata():
    logging.basicConfig(format='%(asctime)s - %(message)s', level=logging.INFO)
    global service_metadata
    metadata_yml_exists: bool = get_metadata_from_yml(metadata_yml_file)
    if not metadata_yml_exists:
        metadata_yml_exists: bool = get_metadata_from_yml(metadata_yaml_file)
    if not metadata_yml_exists:
        logging.info(f"Did not find {metadata_yml_file}. Checking for metadata in environment variables.")
        metadata_exists_in_environ_vars: bool = get_metadata_from_environ()
        if not metadata_exists_in_environ_vars:
            return False
        else:
            f = open(properties_file, "w")
            f.write(yaml.dump(service_metadata))
            f.close()
            logging.info(f"read metadata successfully from environment variables.")
            return
    else:
        f = open(properties_file, "w")
        f.write(yaml.dump(service_metadata))
        f.close()
        logging.info(f"read metadata successfully from yml file.")
        return


def get_metadata_from_yml(file_name: str) -> bool:
    global service_metadata
    if exists(file_name):
        with open(file_name) as file:
            metadata_dict: dict = dict(yaml.load(file, Loader=yaml.FullLoader))
            if service_name in metadata_dict:
                service_metadata[service_name] = metadata_dict[service_name]
            else:
                logging.info(f"{metadata_yml_file} format is wrong.")
                return False
            if service_version in metadata_dict[metadata]:
                service_metadata[metadata][service_version] = metadata_dict[metadata][service_version]
            else:
                logging.info(f"{metadata_yml_file} format is wrong.")
                return False
    else:
        logging.info(f"{metadata_yml_file} not found.")
        return False
    return True


def get_metadata_from_environ() -> bool:
    global service_metadata
    environ_variables = dict(os.environ)
    logging.info(environ_variables)
    if service_name.upper() in environ_variables:
        service_metadata[service_name] = environ_variables[service_name.upper()]
    else:
        logging.info(f"{service_name} not found in environment variables.")

        return False
    if service_version.upper() in environ_variables:
        service_metadata[metadata][service_version] = environ_variables[service_version.upper()]
    else:
        logging.info(f"{service_version} not found in environment variables.")

        return False
    return True


def get_service_list() -> list:
    list_query_body = {
        "queryKey": "Service",
        "groupResults": False,
        "filters": [],
        "columns": [
            {
                "token": "Id",
                "displayName": "Id"
            },
            {
                "token": "Name",
                "displayName": "Name"
            },
            {
                "token": "Type",
                "displayName": "Type"
            },
            {
                "token": "Kind",
                "displayName": "Kind"
            },
            {
                "token": "GitUrl",
                "displayName": "Git url"
            },
            {
                "token": "IncDeps",
                "displayName": "Inc deps"
            },
            {
                "token": "Deps",
                "displayName": "Deps"
            }
        ],
        "orders": [
            {
                "token": "Id",
                "orderType": "Ascending"
            }
        ],
        "pagination": {
            "mode": "Paginate",
            "elementsPerPage": 1000,
            "currentPage": 1
        },
        "queryUrl": "/find/Service"
    }
    return json.loads(
        requests.post(json=list_query_body, headers=headers, url=Operation.EXEC_QRY).content.decode("utf-8"))["rows"]


def service_id_of(service_title: str) -> int:
    service_list: list = get_service_list()

    for service in service_list:
        if service["entity"]["model"] == service_title:
            return service["entity"]["id"]
    raise KeyError(f"service titled {service_title} not found.")


def get_versions_from_service_map(service_id: int) -> list:
    version_list: list = []
    execute_get_bdy = execute_query_body(Operation.EXEC_QRY, service_id)
    response = json.loads(
        requests.post(json=execute_get_bdy, headers=headers, url=Operation.EXEC_QRY).content.decode("utf-8"))["rows"]
    try:
        for entity in response:
            version_list.append(entity['columns'][0]["toStr"])
    except TypeError:
        return version_list
    version_list.sort(reverse=True)
    return version_list


def execute_query_body(query: str, service_id: int, major: str = "0", minor: str = "0", build: str = "0",
                       revision: str = "0") -> dict:
    global service_metadata
    if query == Operation.EXEC_QRY:
        get_body: dict = \
            {"queryKey": "ServiceVersion",
             "groupResults": False,
             "filters": [
                 {"token": "Service",
                  "operation": "EqualTo",
                  "value":
                      {"EntityType": "Service", "id": service_id, "model": service_metadata[service_name]}}],
             "columns": [{"token": "Version"}],
             "orders": [{"token": "Id", "orderType": "Ascending"}],
             "pagination": {"mode": "Paginate", "elementsPerPage": 1000, "currentPage": 1}}
        return get_body
    elif query == Operation.EXEC_ENTITY:
        modify_body: dict = \
            {
                "entity": {
                    "Type": "ServiceVersion",
                    "isNew": True,
                    "modified": True,
                    "service": {
                        "EntityType": "Service",
                        "id": service_id,
                        "model": service_metadata[service_name]
                    },
                    "requiredResources": {
                        "Type": "ResourcesEmbedded",
                        "isNew": True,
                        "modified": True
                    },
                    "version": {
                        "Type": "VersionEmbedded",
                        "isNew": True,
                        "modified": True,
                        "major": major,
                        "minor": minor,
                        "build": build,
                        "revision": revision
                    }
                },
                "operationKey": "ServiceVersionOperation.Save",
                "args": []
            }

        return modify_body
    else:
        raise KeyError(f"command {query} not supported.")


def semantic_versioning(version_string: str) -> Tuple[str, str, str, str]:
    version_array: list[str] = version_string.split(".")
    major: str = version_array[0]
    minor: str = version_array[1]
    if len(version_array) == 3:
        build: str = version_array[2]
        revision: str = "0"
    elif len(version_array) == 4:
        build: str = version_array[2]
        revision: str = version_array[3]
    else:
        build: str = "0"
        revision: str = "0"
    return major, minor, build, revision


def update_version(service_id: int, version: str) -> None:
    """executes a query on service map api an adds given service version to it."""
    versions_from_service_map = get_versions_from_service_map(service_id)
    major, minor, build, revision = semantic_versioning(version)
    if new_version_available():
        execute_modify_bdy = execute_query_body(Operation.EXEC_ENTITY, service_id, major=major, minor=minor,
                                                build=build, revision=revision)
        response: requests.Response = requests.post(json=execute_modify_bdy, headers=headers, url=Operation.EXEC_ENTITY)
        if response.status_code== 200:
            logging.info(f"Previous Versions in ServiceMap: {versions_from_service_map}"
                         f"\nVersion {major}.{minor}.{build}.{revision} was added to ServiceMap.")
            return
        else:
            logging.info(f"following Error occurred from api:{response.status_code}{response.text.encode()}")

    else:
        logging.info(
            f"Version {major}.{minor}.{build}.{revision} already exists in ServiceMap."
        )
        return


def new_version_available() -> bool:
    if get_metadata_from_yml(properties_file):
        versions_in_service_map = get_versions_from_service_map(service_id_of(service_metadata[service_name]))
        latest_proj_version = service_metadata[metadata][service_version]
        return latest_proj_version not in versions_in_service_map
    else:
        return False
