from setuptools import setup

setup(
    name='pypi_ServiceMapUpdates',
    version='0.5.2.6',
    packages=['src'],
    url='',
    license='',
    author='yannick.schiweck',
    author_email='',
    description='',
    entry_points={
        "console_scripts": [
            "smu_upload = src.__main__:main",
            "smu_read = src.update_automation:read_metadata"
        ]

    }
)
